CREATE VIEW BiletWithSpectacol AS
SELECT Bilet.*, Spectacol.*
FROM Bilet
         JOIN Spectacol ON Bilet.id_spectacol = Spectacol.id_spectacol;

